var express = require('express');
var router = express.Router();

var users=[
  {userId:101,name:"Mahesh",email:"M@g",address:"Pune"},
  {userId:102,name:"Ram",email:"R@g",address:"Mumbai"},
  {userId:103,name:"Sachin",email:"S@g",address:"Pune"},
];



/* GET users listing. */
router.get('/', function(request, response, next) {
    response.json(users);
});

/* GET specific user. */
router.get('/:userId', function(request, response, next) {
  var userId=parseInt(request.params.userId);
  var user=users.filter(user=>user.userId==userId)[0];
  response.json(user);
});



/* delete specific user. */
router.delete('/:userId', function(request, response, next) {
  var userId=parseInt(request.params.userId);
  users=users.filter(user=>user.userId!=userId);
  response.json(users);
});



/* update specific user. */
router.put('/:userId', function(request, response, next) {
  var userId=parseInt(request.params.userId);

  users.forEach((user,index)=>{
   if(user.userId==userId)
    users[index]=request.body; 
  })

  response.json(users);
});


/* add specific user. */
router.post('/', function(request, response, next) {
  users.push(request.body);
  response.json(users);
});


module.exports = router;
