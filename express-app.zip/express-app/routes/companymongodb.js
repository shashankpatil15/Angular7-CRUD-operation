var express = require('express');
var router = express.Router();
var mongoose=require("mongoose");

var dbName = 'company';
var connectionString = 'mongodb://localhost:27017/' + dbName;

mongoose.connect(connectionString);

var Schema=mongoose.Schema;

var userSchema = new Schema({
  userId: Number,
  name: String,
  address: String,
  email: String,
});

var  User=mongoose.model('user', userSchema);



/* GET users listing. */
router.get('/users', function(request, response, next) {
    
   User.find(function(err,users){
    if(err)
    return response.send(err);
    response.json(users);
   })

});

/* GET specific user. */
router.get('/users/:userId', function(request, response, next) {
  var userId=parseInt(request.params.userId);

  User.findOne({userId:userId},function(err,user){
    if(err)
    return response.send(err);
    response.json(user);
   })

});



/* delete specific user. */
router.delete('/users/:userId', function(request, response, next) {
  var userId=parseInt(request.params.userId);
  
  var userId=parseInt(request.params.userId);

  User.remove({userId:userId},function(err,user){
    if(err)
    return response.send(err);
  
    User.find(function(err,users){
      if(err)
      return response.send(err);
      response.json(users);
     });
    
  
  })


});



/* update specific user. */
router.put('/users/:userId', function(request, response, next) {
  var userId=parseInt(request.params.userId);


  User.findOne({userId:userId},function (error,user){
    if(error)
    return response.send(error);
    
    for (prop in request.body) {
        user[prop] = request.body[prop];
      }
    user.save();
    User.find(function(err,users){
      if(err)
      return response.send(err);
      response.json(users);
     });
  });
 
  
});


/* add specific user. */
router.post('/users', function(request, response, next) {
  
  var user=new User(request.body);

user.save(function(err){
  if(err)
  return response.send(err);

  User.find(function(err,users){
    if(err)
    return response.send(err);
    response.json(users);
   });
});
});


module.exports = router;
