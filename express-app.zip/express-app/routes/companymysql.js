var express = require('express');
var router = express.Router();
var mysql=require("mysql");

var connection=mysql.createConnection({
user:"root",
password:"admin",
database:"company"  
})

/*

create database company;
use company;

create table users(userId int primary key,name text,address text,dob date,email text);

insert into users values(101,'Pradeep','Pune','2011-11-11',"Pradeep@gmail.com");
insert into users values(102,'Mohan','Mumbai','2012-11-11',"Mohan@gmail.com");
insert into users values(103,'Mahesh','Solapur','2013-11-11',"Mahesh@gmail.com");
insert into users values(104,'Sachin','Pune','2011-11-11',"Sachin@gmail.com");

*/




/* GET users listing. */
router.get('/users', function(request, response, next) {
  
  connection.query("SELECT * FROM USERS",function(err,users){
   if(err)
   return response.send(""+err);
   response.json(users);
  })


});

/* GET specific user. */
router.get('/users/:userId', function(request, response, next) {
  var userId=parseInt(request.params.userId);
  
  connection.query("SELECT * FROM USERS WHERE ID=?",[userId],function(err,users){
    if(err)
    return response.send(""+err);
    response.json(users[0]);
   })
 
});



/* delete specific user. */
router.delete('/users/:userId', function(request, response, next) {
  var userId=parseInt(request.params.userId);
  

  connection.query("DELETE  FROM USERS WHERE ID=?",[userId],function(err,users){
    if(err)
    return response.send(""+err);

  
    connection.query("SELECT * FROM USERS",function(err,users){
      if(err)
      return response.send(""+err);
      response.json(users);
     }) 
  
  })



});



/* update specific user. */
router.put('/users/:userId', function(request, response, next) {
  var userId=parseInt(request.params.userId);
  var  name=request.body.name;
  var  email=request.body.email;
  var  dob=request.body.dob;
  

  connection.query("UPDATE USERS SET NAME=?,EMAIL=?,DOB=? WHERE ID=?",[name,email,dob,userId],function(err,users){
    if(err)
    return response.send(""+err);

  
    connection.query("SELECT * FROM USERS",function(err,users){
      if(err)
      return response.send(""+err);
      response.json(users);
     }) 
  
  })


  
});


/* add specific user. */
router.post('/users', function(request, response, next) {
  

  connection.query("INSERT INTO USERS SET ? ",[request.body],function(err,users){
    if(err)
    return response.send(""+err);

  
    connection.query("SELECT * FROM USERS",function(err,users){
      if(err)
      return response.send(""+err);
      response.json(users);
     }) 
  
  })



});


module.exports = router;
