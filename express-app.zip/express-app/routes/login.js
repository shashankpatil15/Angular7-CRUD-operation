var express = require('express');
var router = express.Router();

router.get("/",function(request,response){
    
    var u=request.query.username;
    var p=request.query.password;
    
    response.send("HEllo   GET :"+u+" Your Password is  "+p+"!!!");
});


router.post("/",function(request,response){
    var u=request.body.username;
    var p=request.body.password;

    response.send("HEllo   GET :"+u+" Your Password is  "+p+"!!!");
    
});




module.exports = router;
