var express = require('express');
var bodyParser=require("body-parser");
var cookieParser=require("cookie-parser");
var expressSession=require("express-session");
var fileUpload=require("express-fileupload");
var cors=require('cors');
var index = require('./routes/index');
var users = require('./routes/users');
var login = require('./routes/login');
var calculate = require('./routes/calculate');
var companymysql = require('./routes/companymysql');
var companymongodb = require('./routes/companymongodb');

var cookiedemo= require('./routes/cookiedemo');
var shopping= require('./routes/shopping');
var upload = require('./routes/upload');

var app = express();
app.use(cors());
app.use(fileUpload());
app.use(cookieParser());
app.use(expressSession({
    resave:true,
    saveUninitialized:true,
    secret:"Hello"
}));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static("public"));


app.use('/', index);
app.use('/users', users);
app.use('/login', login);
app.use('/calculate', calculate);
app.use('/companymysql', companymysql);
app.use('/companymongodb', companymongodb);
app.use('/cookiedemo', cookiedemo);
app.use('/shopping', shopping);
app.use('/upload', upload);

module.exports = app;
